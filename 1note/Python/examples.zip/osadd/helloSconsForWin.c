#include <stdio.h>
#include <stdlib.h>
#include "ext/extScons.h"
int main(int argc, char* argv[])
{
    printf("Hello, SCons in Windows %d!\n", add(1, 2));
    return 0;
} 