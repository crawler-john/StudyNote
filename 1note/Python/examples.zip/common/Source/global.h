#ifndef __GLOBAL_H__
#define __GLOBAL_H__

// _MSC_VER, __GNUC__, __MINGW32__ macros to distinguish between MS VC, GNU C 
// and MinGW compilers
// MS VC++ 9.0 _MSC_VER = 1500
// MS VC++ 8.0 _MSC_VER = 1400
// MS VC++ 7.1 _MSC_VER = 1310
// MS VC++ 7.0 _MSC_VER = 1300
// MS VC++ 6.0 _MSC_VER = 1200
// MS VC++ 5.0 _MSC_VER = 1100
#if defined(_MSC_VER)
#pragma warning(disable:4355)
#pragma warning(disable:4786) 
#endif

#ifdef __cplusplus
#include <cstdio>
#include <cstring>
#include <list>

using namespace std;

#endif  // __cplusplus

#endif // __GLOBAL_H__

