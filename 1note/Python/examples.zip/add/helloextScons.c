#include <stdio.h>
#include <stdlib.h>
#include "extScons.h"
int main(int argc, char* argv[])
{
    printf("Hello, SCons %d!\n", add(1, 2));
    return 0;
} 