var classg =
[
    [ "edges", "classg.html#a4d68519539798c47b152cc364ff40f1b", null ]
];