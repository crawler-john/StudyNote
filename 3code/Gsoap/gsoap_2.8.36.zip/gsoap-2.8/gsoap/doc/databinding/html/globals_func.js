var globals_func =
[
    [ "a", "globals_func.html", null ],
    [ "g", "globals_func_g.html", null ],
    [ "m", "globals_func_m.html", null ],
    [ "s", "globals_func_s.html", null ],
    [ "u", "globals_func_u.html", null ]
];